from matplotlib import pyplot as plt

import os
import math
import numpy as np

from src.Nodes import MaxDistanceSpecifier, CnnProbabilitiesSpecifier
from src.Edges import RelativePositionSpecifier

from src.utils import load_knowledge, load_file, get_diagonal_size, create_images_from_ids, get_one_to_one_matching, get_many_to_one_matching

# configuratio des chemins
DATA_PATH = os.path.join('experiments')

RGB_PATH = os.path.join('data', 'annotation_images')
LABELS_PATH = os.path.join('data', 'annotations')

KNOWLEDGES_DIR = os.path.join(DATA_PATH,  "knowledges")

SEGMENTATION_DIRECTORY = os.path.join(DATA_PATH, "segmentation")

RESULTS_DIRECTORY = os.path.join(DATA_PATH, "results_distance_on_node")

# Configuration des parametres

alpha = 0.5

nb_classes = 3

nodes_specifier = [
    CnnProbabilitiesSpecifier.CnnProbabilitiesSpecifier(),
    MaxDistanceSpecifier.MaxDistandeSpecifier()
]

node_knowledge = load_knowledge(KNOWLEDGES_DIR, 'nodes', nodes_specifier)

edges_specifier = [
    RelativePositionSpecifier.RelativePositionSpecifier()
]

edge_knowledge = load_knowledge(KNOWLEDGES_DIR, 'edges', edges_specifier)

max_node_matching = 3
max_node_refinement = math.inf

# Creation des chemins

if os.path.isdir(RESULTS_DIRECTORY) == False:
    os.mkdir(RESULTS_DIRECTORY)

RESULTS_DIRECTORY_specifier = os.path.join(RESULTS_DIRECTORY)

if os.path.isdir(RESULTS_DIRECTORY_specifier) == False:
    os.mkdir(RESULTS_DIRECTORY_specifier)

# Methodes

files = os.listdir(SEGMENTATION_DIRECTORY)

for f in files:
    
    """""""""""""""""""""""""""""""""""""""
        Chargement des données
    """""""""""""""""""""""""""""""""""""""

    pr_mask = np.load(os.path.join(SEGMENTATION_DIRECTORY, f))
    image_cnn = np.argmax(pr_mask, axis=2)

    gt_mask, affine = load_file(os.path.join(LABELS_PATH, f.replace('.npy', '.png')))
    intensity_input, _ = load_file(os.path.join(RGB_PATH, f.replace('.npy', '.png')))

    dims = len(image_cnn.shape)
    
    """""""""""""""""""""""""""""""""""""""
        Etapes de pre-traitements
    """""""""""""""""""""""""""""""""""""""
    
    params = {}
    
    params['alpha'] = 0.5
    params['Cs'] = get_diagonal_size(image_cnn)
    params['weigthed'] = True
    params['lbd'] = 0.5
    params['min_max_coef'] = 0.5

    pr_mask = pr_mask[:,:, 1:nb_classes + 1]

    """""""""""""""""""""""""""""""""""""""
        Initial matching
    """""""""""""""""""""""""""""""""""""""
    
    best_matching, best_score, labelled_image, regions = get_one_to_one_matching(
        nb_classes=nb_classes,
        params=params,
        image_cnn=image_cnn,
        pr_mask=pr_mask,
        node_knowledge=node_knowledge,
        edge_knowledge=edge_knowledge,
        nodes_specifier=nodes_specifier,
        edges_specifier=edges_specifier,
        nodes_specifier_weigths=[0.5,0.5],
        edges_specifier_weigths=[1]
    )

    matching_image = create_images_from_ids(labelled_image, best_matching)

    proposal_matching, proposal_score = get_many_to_one_matching(
        nb_classes=nb_classes,
        params=params,
        pr_mask=pr_mask,
        labelled_image=labelled_image,
        regions=regions,
        best_matching=best_matching,
        best_score=best_score,
        node_knowledge=node_knowledge,
        edge_knowledge=edge_knowledge,
        nodes_specifier=nodes_specifier,
        edges_specifier=edges_specifier,
        nodes_specifier_weigths=[0.5,0.5],
        edges_specifier_weigths=[1]
    )
           
    proposal_image = create_images_from_ids(labelled_image, proposal_matching)

    # Etape 4 : Sauvegardes des images
 
    figure_path = os.path.join(RESULTS_DIRECTORY_specifier, '{}.png'.format(f))
    
    plt.subplot(1,4,1); plt.title("Annotation"); plt.imshow(gt_mask)
    plt.subplot(1,4,2); plt.title("CNN"); plt.imshow(image_cnn)
    plt.subplot(1,4,3); plt.title("one-to-one"); plt.imshow(matching_image)
    plt.subplot(1,4,4); plt.title("proposal"); plt.imshow(proposal_image)
    plt.tight_layout()
    plt.show()