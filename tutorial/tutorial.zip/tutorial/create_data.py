from tkinter import Image
from typing import Tuple
import numpy as np
import os
import math
import random

from matplotlib import pyplot as plt
from skimage.measure import label, regionprops
from PIL import Image


def create_square(image, value, origin : Tuple, size : Tuple, size_variance_coef = 0.05):

    x,y = image.shape

    x_origin, y_origin = origin[0], origin[1]

    variance = int(size_variance_coef * 100)

    variance_x_origin = random.randint(-variance, variance) / 100
    variance_y_origin = random.randint(-variance, variance) / 100

    x_origin, y_origin = math.floor(x_origin + x * variance_x_origin), math.floor(y_origin + y * variance_y_origin)

    variance_x = random.randint(-variance, variance) / 100
    variance_y = random.randint(-variance, variance) / 100

    size_x, size_y = math.floor(size[0] + size[0] * variance_x), math.floor(size[1] + size[1] * variance_y)

    for i in range(math.floor(x_origin - size_x/2), math.ceil(x_origin + size_x/2)):
        for j in range(math.floor(y_origin - size_y/2), math.ceil(y_origin + size_y/2)):
            image[i][j] = value

    return image

def get_predicted_mask_from_image(image):
    
    nb_labels = len(np.unique(image))

    shape_x, shape_y = image.shape

    probability_map = np.zeros((shape_x, shape_y, nb_labels))

    lbl = label(image, connectivity=2)

    #plt.imshow(lbl); plt.show()

    regions = regionprops(lbl, image)

    for region in regions:

        probs = probs_stats(nb_labels, int(region.max_intensity))

        for c in region.coords:
            x,y = c[0], c[1]

            for i in range(0, nb_labels):
                probability_map[x,y,i] = probs[i]

    
    return probability_map
        

def probs_stats(nb_labels, argmax):

    probs = np.zeros(nb_labels)

    max_prob = random.randint(80,85) / 100

    unaffected_labels = []

    for i in range(0, nb_labels):
        if i != argmax:
            unaffected_labels.append(i)
        else:
            probs[argmax] = max_prob

    index = 0
    for i in unaffected_labels:

        index +=1

        if index == len(unaffected_labels):
            probs[i] = 1 - np.sum(probs)
        else:  
            probs[i] = random.randint(0,100 - int(np.sum(probs) * 100)) / 100

    assert np.sum(probs) == 1

    return probs


annotation_dir = os.path.join('data', 'annotations')
annotation_images = os.path.join('data', 'annotation_images')

pr_dir = os.path.join('experiments', 'segmentation')

output_images_dir = os.path.join('experiments', 'output_images')

nb_image = 20

for i in range(0, nb_image):

    # image originale

    image = np.zeros((128,128))

    image = create_square(image, 1, (35,35), (25,25), 0.05)

    image = create_square(image, 2, (25,100), (15,15), 0.05)

    image = create_square(image, 3, (85,90), (15,15), 0.05)

    image_path = os.path.join(annotation_dir, '{}.png'.format(i))
    img = Image.fromarray(image).convert('L')
    img.save(image_path)

    image_path = os.path.join(annotation_images, '{}.png'.format(i))
    plt.imsave(image_path, image)

    # image bruitée
    
    image = np.zeros((128,128))
    
    image = create_square(image, 1, (30,30), (18,18), 0.05)
    
    image = create_square(image, 2, (40,40), (6,6), 0.05)

    image = create_square(image, 2, (25,100), (15,15), 0.05)

    image = create_square(image, 3, (85,90), (15,15), 0.05)

    image = create_square(image, 1, (10,10), (6,6), 0.05)

    image = create_square(image, 1, (85,35), (20,20), 0.05)

    image = create_square(image, 1, (115,115), (5,5), 0.05)

    image = create_square(image, 2, (25,75), (5,5), 0.05)

    pr_map = get_predicted_mask_from_image(image)

    argmax = np.argmax(pr_map, axis= 2)

    assert np.sum(np.where(argmax == image, 1, 0)) == np.size(image)

    image_path = os.path.join(output_images_dir, '{}.png'.format(i))
    plt.imsave(image_path, argmax)

    segmentation_path = os.path.join(pr_dir, '{}.npy'.format(i))
    np.save(segmentation_path, pr_map)

print("ok")