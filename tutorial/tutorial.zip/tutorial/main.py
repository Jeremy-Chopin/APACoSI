from copy import copy
from matplotlib import pyplot as plt
from skimage.measure import label, regionprops
from copy import deepcopy

import os
import math
import numpy as np

from src.KvConstructor import KvConstructor
from src.Nodes import MaxDistanceSpecifier, CnnProbabilitiesSpecifier

from src.KeConstructor import KeConstructor
from src.Edges import MinMaxEdtDistanceSpecifier, RelativePositionSpecifier

from src.utils import load_knowledge, load_file, define_permutations, permutation_to_matching, get_diagonal_size, create_images_from_ids


def evaluate_matching(matching, kv, ke):
    assert ke is not None or kv is not None
            
    if kv is None:
        K = ke
    elif ke is None:
        K = kv
    else:
        K = alpha * kv + (1-alpha) * ke
    
    X = np.zeros((nb_classes, nb_classes))
    
    for i in range(0, nb_classes):
        for j in range(0, nb_classes):
            if i == j:
                X[i][j] = 1

    vec_x = X.flatten('F')

    x_translate = np.transpose(vec_x)
    tempo = np.matmul(x_translate,K)
    score = np.dot(tempo,vec_x)
    
    return score

# configuratio des chemins
DATA_PATH = os.path.join('experiments')

RGB_PATH = os.path.join('data', 'annotation_images')
LABELS_PATH = os.path.join('data', 'annotations')

KNOWLEDGES_DIR = os.path.join(DATA_PATH,  "knowledges")

SEGMENTATION_DIRECTORY = os.path.join(DATA_PATH, "segmentation")

RESULTS_DIRECTORY = os.path.join(DATA_PATH, "results_distance_on_node")

# Configuration des parametres

alpha = 0.5

nb_classes = 3

nodes_specifier = [
    CnnProbabilitiesSpecifier.CnnProbabilitiesSpecifier(),
    MaxDistanceSpecifier.MaxDistandeSpecifier()
]

node_knowledge = load_knowledge(KNOWLEDGES_DIR, 'nodes', nodes_specifier)

edges_specifier = [
    RelativePositionSpecifier.RelativePositionSpecifier(),
    #MinMaxEdtDistanceSpecifier.MinMaxEdtDistandeSpecifier()
]

edge_knowledge = load_knowledge(KNOWLEDGES_DIR, 'edges', edges_specifier)

max_node_matching = 3
max_node_refinement = math.inf

# Creation des chemins

if os.path.isdir(RESULTS_DIRECTORY) == False:
    os.mkdir(RESULTS_DIRECTORY)

RESULTS_DIRECTORY_specifier = os.path.join(RESULTS_DIRECTORY)

if os.path.isdir(RESULTS_DIRECTORY_specifier) == False:
    os.mkdir(RESULTS_DIRECTORY_specifier)

# Methodes

files = os.listdir(SEGMENTATION_DIRECTORY)

for f in files:

    filename = f.split('_')[0]

    rgb_name = f.replace('_pr.npy', '')
    label_name = rgb_name.replace('ana_strip', 'seg_ana')
    
    """""""""""""""""""""""""""""""""""""""
        Chargement des données
    """""""""""""""""""""""""""""""""""""""

    pr_mask = np.load(os.path.join(SEGMENTATION_DIRECTORY, f))
    image_cnn = np.argmax(pr_mask, axis=2)

    gt_mask, affine = load_file(os.path.join(LABELS_PATH, label_name.replace('.npy', '.png')))
    intensity_input, _ = load_file(os.path.join(RGB_PATH, rgb_name.replace('.npy', '.png')))

    dims = len(image_cnn.shape)
    
    """""""""""""""""""""""""""""""""""""""
        Etapes de pre-traitements
    """""""""""""""""""""""""""""""""""""""
    
    params = {}
    
    params['Cs'] = get_diagonal_size(image_cnn)
    params['weigthed'] = True
    params['lbd'] = 0.5
    params['min_max_coef'] = 0.5

    pr_mask = pr_mask[:,:, 1:nb_classes + 1]

    """""""""""""""""""""""""""""""""""""""
        Initial matching
    """""""""""""""""""""""""""""""""""""""
    
    labelled_image = label(image_cnn)
    regions = regionprops(labelled_image, image_cnn)
    
    M = define_permutations(regions, nb_classes)
    
    
    best_matching = None
    best_score = math.inf
    for permutation in M:
        
        matching = permutation_to_matching(permutation)
    
        kv_constructor = KvConstructor(nodes_specifier, [0.5,0.5], node_knowledge)
        
        kv = kv_constructor.construct_Kv(pr_mask, labelled_image, regions, matching, params)
        
        ke_constructor = KeConstructor(edges_specifier, [1], edge_knowledge)
        
        ke = ke_constructor.construct_Ke(pr_mask, labelled_image, regions, matching, params)
        
        score = evaluate_matching(matching, kv, ke)
        
        if score < best_score:
            best_score = score
            best_matching = matching

    matching_image = create_images_from_ids(labelled_image, best_matching)
        
    """""""""""""""""""""""""""""""""""""""
        Refinement
    """""""""""""""""""""""""""""""""""""""
    
    list_ids = list(np.unique(labelled_image)[1:])
    
    for k,v in best_matching.items():
        for node in v:
            list_ids.remove(node)
    
    temp_best_matching = deepcopy(best_matching)
    temp_best_score = best_score
    
    for ids in list_ids:
        
        class_best_matching = temp_best_matching
        class_best_score = math.inf
        
        for cls in range(0, nb_classes):
            temp_matching = deepcopy(temp_best_matching)
            
            temp_matching[cls].append(ids)
            
            kv_constructor = KvConstructor(nodes_specifier, [0.5,0.5], node_knowledge)
        
            kv = kv_constructor.construct_Kv(pr_mask, labelled_image, regions, temp_matching, params)
            
            ke_constructor = KeConstructor(edges_specifier, [1.0], edge_knowledge)
            
            ke = ke_constructor.construct_Ke(pr_mask, labelled_image, regions, temp_matching, params)
            
            score = evaluate_matching(temp_matching, kv, ke)
            
            if score < class_best_score:
                class_best_score = score
                class_best_matching = temp_matching
        
        if class_best_score < temp_best_score:
            temp_best_score = class_best_score
            temp_best_matching = class_best_matching
    

    
    proposal_image = create_images_from_ids(labelled_image, temp_best_matching)
        
    """plt.subplot(1,4,1); plt.title("Annotation"); plt.imshow(gt_mask)
    plt.subplot(1,4,2); plt.title("CNN"); plt.imshow(image_cnn)
    plt.subplot(1,4,3); plt.title("one-to-one"); plt.imshow(results)
    plt.subplot(1,4,4); plt.title("proposal"); plt.imshow(results2)
    plt.tight_layout()
    plt.show()"""

    # Etape 4 : Sauvegardes des images
 
    figure_path = os.path.join(RESULTS_DIRECTORY_specifier, '{}.png'.format(f))
    
    plt.subplot(1,4,1); plt.title("Annotation"); plt.imshow(gt_mask)
    plt.subplot(1,4,2); plt.title("CNN"); plt.imshow(image_cnn)
    plt.subplot(1,4,3); plt.title("one-to-one"); plt.imshow(matching_image)
    plt.subplot(1,4,4); plt.title("proposal"); plt.imshow(proposal_image)
    plt.tight_layout()
    plt.show()
    #plt.savefig(figure_path.replace('.npy', '.png'))
    #plt.close()